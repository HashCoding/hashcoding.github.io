﻿# HashCoding

[百度前端技术学院](http://ife.baidu.com) 热身训练作品

点击[这里](http://hashcoding.github.io)进入

## 约定

* 各自完成组件，本地测试完成后，将组件目录置于components下
* 组件完成且测试成功后，把HTML代码填充到 `index.html` ，并引入相应的css和js文件
* 大家一起 `review`，一切顺利的话，合并打包发布

## ToDo

* 打包构建
